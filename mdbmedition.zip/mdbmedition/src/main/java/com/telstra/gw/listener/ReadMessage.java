package com.telstra.gw.listener;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

/**
 * Created by orcilia on 21/03/2018.
 */
@Component

public class ReadMessage {
    @JmsListener(destination = "private.queue1")
    public void handleMessage(String message){
        System.out.println("received: "+message);
    }
}
